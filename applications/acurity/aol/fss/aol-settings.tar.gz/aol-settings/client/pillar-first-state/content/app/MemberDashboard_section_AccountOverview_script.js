(function ( options ) {

    options.sections.accountOverview = {};

    options.sections.accountOverview.complete = function( scope ) {
        scope.$eb.once({
            "event": "MemberDashboard.getMemberTransactionDetailsDashboard.success",
            "handler": function ( eventName, data ) {
                // set data
                scope.setPlainObjectContentData(  data );

            }
        });

    }



});