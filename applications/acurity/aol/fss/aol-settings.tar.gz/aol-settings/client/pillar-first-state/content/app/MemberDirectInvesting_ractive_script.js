(function ( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;

    options.complete = function () {
        var ractive = this;
        var $eb = ractive.$eb;
        var $ = $wnd.$;

        $( '#testErrorButton' ).on( 'click', function ( e ) {
            FSSWEB.finSynAPI.pageSpinner.start();
            FSSWEB.finSynAPI.pageSpinner.stop();
            FSSWEB.finSynAPI.modals.open( 'test-error-modal', function(){}, {}, '{}', null );
        });

        $( '#testRedirectButton' ).on( 'click', function ( e ) {
            FSSWEB.finSynAPI.pageSpinner.start();
            FSSWEB.finSynAPI.pageSpinner.stop();
            window.location = "http://www.google.com.au";
        });
    };
});