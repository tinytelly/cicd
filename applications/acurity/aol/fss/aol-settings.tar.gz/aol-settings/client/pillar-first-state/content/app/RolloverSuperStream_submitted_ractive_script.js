(function(options) {
    var window = $wnd;
    var $ = $wnd.$;
    var FinSyn = $wnd.FinSyn;
    var FSSWEB = $wnd.FSSWEB;

    options.init = function() {
        //setup ractive level function
        var $ractive = this;
        $ractive.$fss_update = FSSWEB.update;
    }

    options.complete = function() {
        var $ractive = this;
        var $eb = $ractive.$eb;

        $( '.formpanel__savelink .cta--primary' ).on( 'click', function( e ) {
            window.location = '#MemberDashboard';
        } );
    }
});