(function( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;
    //options.data.$place = {};

    //setup oncomplete binding
    options.complete = function () {
        var ractive = this;
        var $eb = ractive.$eb;

        $( '.centrelink-schedule__bottombar .download' ).on( 'click', function( e ) {

            FSSWEB.finSynAPI.pageSpinner.start();
            FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'update-centerlink-schedule',null);

            var cleanup = function() {
                $eb.off( noDocHandler );
                $eb.off( failureHandle );
                $eb.off( successHandle );
            }

            var successHandle = $eb.on( "CentrelinkSchedule.getDownload.downloaded", function ( eventName, data ) {
                var downloadAnchor = $( '.download-centrelink a.download' );
                FSSWEB.finSynAPI.pageSpinner.stop();
                FSSWEB.finSynAPI.modals.open(
                        'download-centrelink',
                        function(){
                            //downloadAnchor.attr( 'href', data.downloadUrl );
                        }, {}, '{}',
                        {
                            'download': function () {
                                //downloadAnchor.attr( 'href', 'javascript:;' );
                                window.open( data.downloadUrl, '_self' );
                                FSSWEB.finSynAPI.modals.close();
                            },
                            'back': function() {
                                //downloadAnchor.attr( 'href', 'javascript:;' );
                            }
                        }
                );
                cleanup();
            } );

            var failureHandle = $eb.on( 'CentrelinkSchedule.getDownload.failed', function( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                FSSWEB.finSynAPI.modals.open( 'unable-download-centrelink', function(){}, {}, '{}', {} );
                cleanup();
            } );

            var noDocHandler = $eb.on( 'CentrelinkSchedule.getDownload.noDocument', function( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                FSSWEB.finSynAPI.modals.open( 'unable-download-centrelink', function(){}, {}, '{}', {} );
                cleanup();
            } );

            $eb.trigger( "CentrelinkSchedule.getDownload", null );
        } );
    }
});
