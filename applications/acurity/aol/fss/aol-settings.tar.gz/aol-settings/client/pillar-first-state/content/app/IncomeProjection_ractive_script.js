(function ( options ) {
    var window = $wnd;
    var Promise = window.Promise;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;

    options.incProj = {};

    options.incProj.constructDataModel = function() {
        options.incProj.dataModel = {
            displayContent: "Calc",
            soa: {}
        };
    };

    options.incProj.constructUI = function() {
        options.incProj.updateUI();
        options.incProj.getWtwUI().then( function( wtwUI ) {
            // give wtw a chance to do some cleanup
            options.incProj.ractive.on( 'teardown', wtwUI.destroy );
            wtwUI.launch( {
                element: "income-proj",
                calculatorName: "IncomeProjection",
                dataProvider: options.incProj.getDataProviderPromise(),
                soaDataCallback: options.incProj.getStoreSoaCallback(),
                soaDisplayCallback: options.incProj.getSubmitSoaCallback(),
                analyticsCallback: window.digitalData
            } );
        } );
    };

    options.incProj.updateUI = function() {
        options.incProj.ractive.set( "dataModel", options.incProj.dataModel );
    };

    options.incProj.getWtwUI = function() {
        return options.incProjSoa.getWtwUI();
    };

    options.incProj.getDataProviderPromise = function() {
        return new Promise( function( resolve, reject ) {
            $.ajax( {
                type: "GET",
                url: "rest/incomeProjection/calcData",
                headers: {
                    "AOL-Session-Key": options.data.rc.sessionKey
                },
                success: function ( data, textStatus, jqxhr ) {
                    var dataObj = JSON.parse( data );
                    resolve( dataObj );
                },
                error: function ( xhr, status, error ) {
                    reject( error );
                }
            } );
        } );
    };

    options.incProj.getStoreSoaCallback = function() {
        return function( soa ) {
            var enhancedData = options.incProj.enhanceData( soa );
            return new Promise( function ( resolve, reject ) {
                $.ajax( {
                    type: "PUT",
                    url: "rest/incomeProjection/soaData",
                    headers: {
                        "Content-Type": "application/json",
                        "AOL-Session-Key": options.data.rc.sessionKey
                    },
                    data: JSON.stringify( {
                        data: JSON.stringify( enhancedData )
                    } ),
                    success: function ( data, textStatus, jqxhr ) {
                        resolve( data );
                    },
                    error: function ( xhr, status, error ) {
                        reject( error );
                    }
                } );
            } );
        };
    };

    options.incProj.getSubmitSoaCallback = function() {
        return function( soa ) {
            window._aol_hook_spinner_start();
            var enhancedData = options.incProj.enhanceData( soa );
            return new Promise( function( resolve, reject ) {
                $.ajax( {
                    type: "POST",
                    url: "rest/incomeProjection/soaData",
                    headers: {
                        "Content-Type": "application/json",
                        "AOL-Session-Key": options.data.rc.sessionKey
                    },
                    data: JSON.stringify( {
                        data: JSON.stringify( enhancedData )
                    } ),
                    success: function ( data, textStatus, jqxhr ) {
                        window._aol_hook_spinner_stop();
                        options.incProj.displaySoa( enhancedData );
                        resolve( data );
                    },
                    error: function ( xhr, status, error ) {
                        window._aol_hook_spinner_stop();
                        options.incProj.displayError( xhr.responseJSON );
                        resolve( "error" );
                    }
                } );
            } );
        };
    };

    options.incProj.displayError = function( error ) {
        var msg = {};
        if ( error ) {
            msg.aest_error_time = new Date( error.dateTime );
            msg.ticket = error.ticket;
        } else {
            msg.aest_error_time = new Date();
            msg.ticket = false;
        }
        options.incProj.dataModel.displayContent = "Error";
        options.incProj.dataModel.soa = msg;
        options.incProj.updateUI();
        options.incProj.scrollTop();
    };

    options.incProj.displaySoa = function( soa ) {
        options.incProj.dataModel.displayContent = "Soa";
        options.incProj.dataModel.soa = soa;
        options.incProj.updateUI();
        options.incProj.scrollTop();
    };

    options.incProj.enhanceData = function( soa ) {
        if ( soa ) {
            soa.workaround = { "currentDate": options.data.rc.currentDate, "clientFullName": options.data.rc.clientFullName };
        }
        return soa;
    };

    options.incProj.scrollToId = function( event, elementId ) {
        var $ = $wnd.$;
        var offset = 150; // FSS fixed header height
        $('html, body').animate({scrollTop: $(elementId).offset().top - offset }, 'slow');
        // window.document.getElementById(elementId).scrollIntoView();
    };

    options.incProj.scrollTop = function() {
        $("html, body").animate({ scrollTop: 0 }, "slow");
    };

    options.complete = function () {
        options.incProj.ractive = this;
        options.incProj.constructDataModel();
        options.incProj.constructUI();
        options.incProj.ractive.on( 'scrollToId', options.incProj.scrollToId );
    };
});