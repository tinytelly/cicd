(function ( options ) {

    options.sections.insurance = {};

    options.sections.insurance.currentSelected = {};

    options.sections.insurance.select = function( scope, selectedId ) {
        var details = scope.getData( 'insuranceDashboard' );
        if ( selectedId !== 'all' ) {
            details = details.detailsMap[ selectedId ]
        }

        var currentSelected = options.sections.insurance.currentSelected;
        currentSelected.id = selectedId;
        currentSelected.zeroBalance = details.zeroBalance;
        currentSelected.hasInsurance = details.hasInsurance;
        currentSelected.fundCode = details.fundCode;
        currentSelected.memberNumber = details.memberNumber;
        scope.setData( "selectedInsurance", currentSelected );
    };

    options.sections.insurance.complete = function( scope ) {
        scope.$eb.once({
            "event": "MemberDashboard.getClientInsuranceDashboard.success",
            "handler": function ( eventName, data ) {
                // set data
                scope.setPlainObjectContentData( data );
                // select all by default
                options.sections.insurance.select( scope, "all" );
                // register listener to insurance selection
                scope.ractive.on( "selectInsurance", function( event, selectedId ) {
                    options.sections.insurance.select( scope, selectedId );
                } );
            }
        });
    }
});