(function ( options ) {

    options.sections.tacticalLinks = {};

    options.sections.tacticalLinks.complete = function( scope ) {

    }
});