(function( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;
    //options.data.$place = {};

    //setup oncomplete binding
    options.complete = function () {
        var ractive = this;
        var $eb = ractive.$eb;

        $('#create-new-password' ).on( 'panelWasSubmitted.finsyn-flowformNav', function( e ) {
            FSSWEB.finSynAPI.flowforms.startSpinner()

            var cleanup = function() {
                $eb.off( serverCallFailed );
                $eb.off( failureHandle );
                $eb.off( successHandle );
            }

            var successHandle = $eb.on( "Login.MustChangePassword.success", function ( eventName, data ) {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                cleanup();
            } );

            var failureHandle = $eb.on( 'Login.MustChangePassword.failure', function( eventName, data ) {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                cleanup();
            } );

            var serverCallFailed = $eb.on( 'Login.MustChangePassword.serverFailure', function( eventName, data ) {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                cleanup();
            } );

            $eb.trigger( "Login.MustChangePassword", null );
        } );




        /*$('#update-contact-details' ).on( 'panelWasSubmitted.flowformNav', function( e ) {

            FSSWEB.finSynAPI.pageSpinner.start();

            var cleanup = function() {
                $eb.off( serverCallFailed );
                $eb.off( failureHandle );
                $eb.off( successHandle );
            }

            var successHandle = $eb.on( "Login.UpdateContactDetails.success", function ( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                cleanup();
                FSSWEB.finSynAPI.flowforms.nextPanel();
            } );

            var failureHandle = $eb.on( 'Login.UpdateContactDetails.failure', function( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                cleanup();
            } );

            var serverCallFailed = $eb.on( 'Login.UpdateContactDetails.serverFailure', function( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                cleanup();
            } );

            $eb.trigger( "Login.UpdateContactDetails", null );
        } );

        $('#agree-to-tax-file-number-use' ).on( 'panelWasSubmitted.flowformNav', function( e ) {

        } );*/

    }
});