(function ( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;

    options.complete = function () {
        //jquery binding
        var ractive = this;
        var $eb = ractive.$eb;
        var $ = $wnd.$;

        //var jsonDataForChart = ractive.get('rc').jsonDataForChart;

    }
});