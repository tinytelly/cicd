(function( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;
    //options.data.$place = {};

    options.data.isNotBlank = function(item){
        if(item!=null && item.getValue()!=null && item.getValue() !=''){
            return true;
        }else {
            return false;
        }
    };

    options.data.isBlank = function(item){
        if(item==null || item.getValue()==null || item.getValue() ==''){
            return true;
        }else {
            return false;
        }
    };

    //evaluate init state of workPhone and homePhone
    options.data.initHomePhoneSelected = options.data.isNotBlank(options.data.mustChangePasswordForm.homePhone);
    options.data.initWorkPhoneSelected = options.data.isNotBlank(options.data.mustChangePasswordForm.workPhone);

    //setup oncomplete binding
    options.complete = function () {
        var ractive = this;
        var $eb = ractive.$eb;
        var form = options.data.mustChangePasswordForm;

        $('#create-new-password' ).on( 'panelWasSubmitted.finsyn-flowformNav', function( e ) {
            // make only password fields visible.
            form.email.setVisible(false);
            form.confirmEmail.setVisible(false);
            form.homePhone.setVisible(false);
            form.workPhone.setVisible(false);
            form.mobilePhone.setVisible(false);
            if( form.validate() ) {
                FSSWEB.finSynAPI.flowforms.nextPanel();
                // force trigger of recommended mobile number warning by drawing focus to the field.
                $( '#contact-phone-number' ).focus();
            } else {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
            }
        } );

        $('#contact-phone-number' ).on('blur', function(e) {
            var value = $('#contact-phone-number' ).val();
            if( value == '' ) {
                $('#contact-phone-number-warning' ).removeClass( "js-hidden" );
            } else {
                $('#contact-phone-number-warning' ).addClass( "js-hidden" );
            }
        });

        $('#update-contact-details' ).on( 'panelWasSubmitted.finsyn-flowformNav', function( e ) {
            // make all fields visible.
            form.email.setVisible(true);
            form.confirmEmail.setVisible(true);
            form.homePhone.setVisible(true);
            form.workPhone.setVisible(true);
            form.mobilePhone.setVisible(true);
            if( form.validate() ) {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                $eb.trigger( "Login.UpdateContactDetails", null );
            } else {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
            }
        } );

        if ( form.context.isGreenIDVerified == "true" ) {
            // Skip the Create New Password step, go straight to Update Contact Details
            // make all fields visible.
            form.email.setVisible(true);
            form.confirmEmail.setVisible(true);
            form.homePhone.setVisible(true);
            form.workPhone.setVisible(true);
            form.mobilePhone.setVisible(true);
            FSSWEB.finSynAPI.flowforms.nextPanel();
            FSSWEB.finSynAPI.flowforms.stopSpinner();
            setTimeout ( function() {
                $('#contact-phone-number').focus();
            }, 10);
        }

    }
});