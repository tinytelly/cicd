(function( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;
    //options.data.$place = {};

    var PID_LOGIN = 1;
    var PID_FIND_MEMBER_NUMBER = 2;

    options.login = {};

    //setup oncomplete binding
    options.complete = function () {
        var ractive = this;
        var $eb = ractive.$eb;

        var onkeypressevent = function( e ) {
            if (e.which == 13 || e.keyCode == 13) {
                $('.panel-1.layout-item input' ).off( 'keypress');
                $('.cta--centered' ).off( 'click');
                onevent(e);
            }
        };

        var onclickevent = function( e ) {
                 $('.cta--centered' ).off( 'click');
                onevent(e);
         };

        var onevent = function( e ) {

            var cleanup = function () {
                $eb.off( serverCallFailed );
                $eb.off( failureHandle );
                $eb.off( successHandle );
            }

            var successHandle = $eb.on( "Login.loginTemplateFlow.success", function ( eventName, data ) {
                $wnd.FSSWEB.finSynAPI.analytics.setProcessComplete('ssc', 'login',null);
                FSSWEB.finSynAPI.pageSpinner.stop();
                cleanup();
            } );

            var failureHandle = $eb.on( 'Login.loginTemplateFlow.failure', function ( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                cleanup();
            } );

            var serverCallFailed = $eb.on( 'Login.loginTemplateFlow.serverFailure', function ( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                cleanup();
            } );

            if ( options.data.loginForm.validate() ) {
                FSSWEB.finSynAPI.pageSpinner.start();
                $eb.trigger( "Login.loginTemplateFlow", null );
            } else {
                $( '.panel-1.layout-item input' ).on( 'keypress', onkeypressevent );
                $('.cta--centered' ).on( 'click', onclickevent);
            }

        };

        $('.cta--centered' ).on( 'click', onclickevent);

        $('.panel-1.layout-item input' ).on( 'keypress', onkeypressevent);

        options.login.switchToPanel( PID_LOGIN );
        $('#aoli-btn-find-member-number' ).on( 'click', function( e ) {
            e.preventDefault();
            options.login.switchToPanel( PID_FIND_MEMBER_NUMBER );
        } );
        $('#aoli-find-member-number-panel .aolc-back' ).on( 'click', function( e ) {
            e.preventDefault();
            options.login.switchToPanel( PID_LOGIN );
        } );

        FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'login',null);

    }

    options.login.switchToPanel = function ( panelId ) {
        // login panel
        $( '#login-panel' ).toggle( panelId === PID_LOGIN );

        // find member panel
        $( '#aoli-find-member-number-panel' ).toggle( panelId === PID_FIND_MEMBER_NUMBER );

        $wnd.$( window ).scrollTop(0);
    }
});