(function( options ) {
    var window = $wnd;
    var $ = $wnd.$;
    var FSSWEB = $wnd.FSSWEB;

    options.complete = function () {
        var $ractive = this;
        var $eb = $ractive.$eb;
        $wnd.FSSWEB.finSynAPI.analytics.setProcessComplete('ssc', 'join',null);
    };

    window.onComponent1Complete = function() {
        FSSWEB.iCantBelieveItsNotGrunticon.init();

    };

    window.onComponent2Complete = function() {
        FSSWEB.finSynAPI.analytics.resetEventListeners();

    };

});
