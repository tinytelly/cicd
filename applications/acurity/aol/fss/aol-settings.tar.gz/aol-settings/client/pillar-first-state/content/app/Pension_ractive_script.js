(function( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;

    options.data.isPensionDetailsUpdateFormEditable = function() {
        return this.get('rc').pensionDetailsUpdateFormEditable === 'true';
    };

    options.data.isPensionSetupDebitUpdateFormEditable = function() {
        return this.get('rc').pensionSetupDebitUpdateFormEditable === 'true';
    };

    options.complete = function() {
        var $ractive = this;
        var $eb = $ractive.$eb;

        var reloadWindow = function() {
            window.location = '#Pension';
        };

        // PensionDetailsUpdateForm - Cancel button
        $( '#payment-nav .fn_setFormpanelDefaults' ).on( 'click', function ( e ) {
            reloadWindow();
        } );

        $('.PensionPlace').on('click','a[data-show-ids="payment-nav, payment-form"]', function(event){
            FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'change-payment-schedule',null);
        });

        // PensionDetailsUpdateForm - Save button
        $( '#payment-nav .cta-icon-free' ).on( 'click', function ( e ) {
            var success = {
                "event" : "Pension.PensionDetailsUpdateForm.success",
                "handler" : function( event, data ) {
                    FSSWEB.finSynAPI.analytics.setProcessComplete('ssc', 'change-payment-schedule',null);
                    reloadWindow();
                }
            };
            var failed = {
                "event" : "Pension.PensionDetailsUpdateForm.failed",
                "handler" : function( event, data ) {
                    console.error( "PensionDetailsUpdateForm save failed." )
                }
            };
            $eb.once( success, failed );
            $eb.trigger( 'Pension.PensionDetailsUpdateForm.save', null );
        } );

        // PensionSetupDebitUpdateForm - Cancel button
        $( '#nominated-nav .fn_setFormpanelDefaults' ).on( 'click', function ( e ) {
            reloadWindow();
        } );

        $('.PensionPlace').on('click','a[data-show-ids="nominated-nav, nominated-form"]', function(event){
            FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'change-bank-account',null);
        });

        // PensionSetupDebitUpdateForm - Save button
        $( '#nominated-nav .cta-icon-free' ).on( 'click', function ( e ) {
            var success = {
                "event" : "Pension.PensionSetupDebitUpdateForm.success",
                "handler" : function( event, data ) {
                    FSSWEB.finSynAPI.analytics.setProcessComplete('ssc', 'change-bank-account',null);
                    reloadWindow();
                }
            };
            var failed = {
                "event" : "Pension.PensionDetailsUpdateForm.failed",
                "handler" : function( event, data ) {
                    console.error( "PensionSetupDebitUpdateForm save failed." )
                }
            };
            $eb.once( success, failed );
            $eb.trigger( 'Pension.PensionSetupDebitUpdateForm.save', null );
        } );

        $eb.on( "System.2fa.display2faDialog", function( eventname, twoFaData ) {
            // Update the 2fa data in the ractive model and inform ractive it's changed.
            options.data.twoFaData = twoFaData;
            $ractive.update( 'twoFaData' );
            $('#one-time-pin').val('');
            $('#modal-2fa-error' ).addClass('js-hidden');
            // Open the dialog.
            FSSWEB.finSynAPI.modals.open( 'modal-2fa', null, null, null, {
                '2fa-cancel': function () {
                    $eb.trigger( 'System.2fa.dialogCancelled' );
                },
                '2fa-authorise': function () {
                    var token = $('#one-time-pin').val();
                    $eb.trigger( 'System.2fa.dialogAuthorise', { "token" : token } );
                },
                '2fa-resend': function () {
                    $eb.trigger( 'System.2fa.dialogResend' );
                }
            } );
            window._aol_hook_on_dialog_dismiss( function() {
                $eb.trigger( 'System.2fa.dialogCancelled' );
            } );
        } );

        $eb.on( "System.2fa.resendComplete", function( eventname, twoFaData ) {
            // Update the 2fa data in the ractive model and inform ractive it's changed.
            options.data.twoFaData = twoFaData;
            $ractive.update( 'twoFaData' );
            $('#one-time-pin').val('');
            $('#modal-2fa-error' ).addClass('js-hidden');

        } );

        $eb.on( "System.2fa.dismiss2FaDialog", function( eventname, twoFaData ) {
            FSSWEB.finSynAPI.modals.close();
            window._aol_hook_on_after_dialog_dismiss();
        } );

        $eb.on( "System.2fa.error", function( eventname, twoFaData ) {
            $('#modal-2fa-error' ).removeClass('js-hidden');
        } );
    }
});