(function( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;
    var PID_Member_Details = 'member-details';
    var PID_Verify_Details = 'verify-details';
    var PID_New_Password = 'new-password';
    var PID_Review_And_Submit = 'review-and-submit';

    options.memberJoin = {};

    options.memberJoin.registerEventListeners = function($eb) {

        var defaultPostalQAS = options.data.memberJoinForm.searchAddress.getValue();
        var defaultResidentialQAS = options.data.memberJoinForm.residentialSearchAddress.getValue();

        // Show / Hide Residential Address for International Addressing
        $( '#sel_country' ).on( 'change', function ( e ) {
            var value = $( e.target ).val();
            if ( value != 'Australia' ) {
                $('.residential-address-section.fn_addressControl .qas').hide();
                $('.residential-address-section.fn_addressControl .non-qas').show();
                $eb.trigger( 'MemberJoin.memberDetails.showHideAddress1' );
            }
        } );
        // Show / Hide Postal Address for International Addressing
        $( '#sel_country-r' ).on( 'change', function ( e ) {
            var value = $( e.target ).val();
            if ( value != 'Australia' ) {
                $('.postal-address-section.fn_addressControl .qas').hide();
                $('.postal-address-section.fn_addressControl .non-qas').show();
                $eb.trigger( 'MemberJoin.memberDetails.showHideAddress2' );
            }
        } );

        //Show/Hide TFN based on checkbox
        $( '#tfn-check-area1_tfn-check' ).on( 'change', function ( e ) {
            var checked = $( e.currentTarget ).val();
            var data = { "checked": checked };
            $eb.trigger( 'MemberJoin.memberDetails.showHideTfn', data );
        } );

        //Different address
        $( '#address-type_address-type-check' ).on( 'change', function ( e ) {
            var checked = $( e.currentTarget ).val();
            var data = { "checked": checked };
            $eb.trigger( 'MemberJoin.memberDetails.differentPostalAddress', data );
        } );

        $('#contact-phone-number' ).on('blur', function(e) {
            var value = $('#contact-phone-number' ).val();
            if( value == '' ) {
                $('#contact-phone-number-warning' ).removeClass( "js-hidden" );
            } else {
                $('#contact-phone-number-warning' ).addClass( "js-hidden" );
            }
        });

        $( '#res-add-link1' ).on('click', function ( e ) {
            e.preventDefault();
            $eb.trigger( 'MemberJoin.memberDetails.showHideAddress1' );
            $('#address-line-1').val('');
            $('#address-line-2').val('');
            $('#residential-state').val('').trigger('change');
            $('#residential-city').val('');
            $('#postcode').val('');
            $('#int-city1').val('');
        } );

        $( '#res-add-link2' ).on('click', function ( e ) {
            e.preventDefault();
            $('#sel_country').val("Australia").trigger('change');
            $eb.trigger( 'MemberJoin.memberDetails.showOneLineAddress1' );
            $('#res-add-id').val('');
        } );

        $( '#post-add-link1' ).on('click', function ( e ) {
            e.preventDefault();
            $eb.trigger( 'MemberJoin.memberDetails.showHideAddress2' );
            $('#pos-add-ln1-id').val('');
            $('#pos-add-ln2-id').val('');
            $('#pos-add-st-id').val('').trigger('change');
            $('#pos-add-cty-id').val('');
            $('#pos-add-po-id').val('');
            $('#pos-non-au-add').val('');
        });

        $( '#post-add-link2' ).on('click', function ( e ) {
            e.preventDefault();
            $( '#sel_country-r' ).val("Australia").trigger('change');
            $eb.trigger( 'MemberJoin.memberDetails.showOneLineAddress2' );
            $('#pos-add-id').val('');
        });

        //listen on twofa token
        $eb.on( 'MemberJoin.verifyContact.tokenSent', function ( eventName, data ) {
            FSSWEB.finSynAPI.wizard.stopSpinner();
            if ( data.tokenSentTo == 'sms' ) {
                $( '#tokenSentToSmsMsg' ).show();
                $( '#tokenSentToEmailMsg' ).hide();
            } else if ( data.tokenSentTo == 'email' ) {
                $( '#tokenSentToSmsMsg' ).hide();
                $( '#tokenSentToEmailMsg' ).show();
            } else {
                $( '#tokenSentToSmsMsg' ).hide();
                $( '#tokenSentToEmailMsg' ).hide();
            }
        } );

        //Step 3 - Optional Resend Token
        $( '#verify-details .resentToken' ).on( 'click', function ( e ) {
            FSSWEB.finSynAPI.wizard.startSpinner();
            $eb.trigger( 'MemberJoin.verifyContact.sendToken' );
        } );


        //Making sure that valid address is selected form the list

        //DOB listener
        $('.date-control__container .day').on("focusout",function(event){
            $('.dob-wrapper').removeClass('form-control--error');
            $('#personal-dob').removeClass('error');
        });
        $('.date-control__container .month').on("focusout",function(event){
            $('.dob-wrapper').removeClass('form-control--error');
            $('#personal-dob').removeClass('error');
        });
        $('.date-control__container .year').on("focusout",function(event){
            $('.dob-wrapper').removeClass('form-control--error');
            $('#personal-dob').removeClass('error');
        });

        //QAS Trigger
        $('.residentialQASPicker').on('change', function(event){
            var pickerValue = event.currentTarget.value;
            if ( pickerValue == "" ) {
                event.currentTarget.value = defaultResidentialQAS;
            }

            var options = $( '.MemberJoinPlace .residentialQASAutocompleteListWrap label' ).toArray();
            for ( var i = 0; i < options.length; i++ ) {
                if ( options[i].innerHTML == pickerValue ) {
                    defaultResidentialQAS = pickerValue;
                    return;
                }
            }
            event.currentTarget.value = defaultResidentialQAS;

        });
        $('#res-address-2 #address-line-1').on('change', function(event){

        });
        $('#res-address-2 #address-line-2').on('change', function(event){

        });
        $('#res-address-2 #residential-city').on('change', function(event){

        });

        $('#res-address-2 #postcode').on('change', function(event){

        });

        $('.postalQASPicker').on('change', function(event){
            var pickerValue = event.currentTarget.value;
            if ( pickerValue == "" ) {
                event.currentTarget.value = defaultPostalQAS;
            }

            var options = $( '.MemberJoinPlace .postalQASAutocompleteListWrap label' ).toArray();
            for ( var i = 0; i < options.length; i++ ) {
                if ( options[i].innerHTML == pickerValue ) {
                    defaultPostalQAS = pickerValue;
                    return;
                }
            }
            event.currentTarget.value = defaultPostalQAS;

        });
        $('#postal-address-2 #pos-add-ln1-id').on('change', function(event){

        });
        $('#postal-address-2 #pos-add-ln2-id').on('change', function(event){

        });
        $('#postal-address-2 #pos-add-cty-id').on('change', function(event){

        });

        $('#postal-address-2 #pos-add-po-id').on('change', function(event){

        });



        $( '.wizard button.next' ).off('click.nextStep');
        $( '#member-details' ).on( 'click', '.next', options.memberJoin.step1);
        $( '#verify-details' ).on( 'click', '.back', function() {
                    options.memberJoin.goBack(PID_Verify_Details)
        } );
        $( '#verify-details' ).on( 'click', '.next', options.memberJoin.step2 );

        $( '#new-password' ).on( 'click', '.next', options.memberJoin.step3 );
        $('#review-and-submit .Join').on('click', options.memberJoin.step4);



        $('#review-and-submit').on('click', '.personal-details-summary a', function(e){
            e.preventDefault();
            FSSWEB.finSynAPI.newWizard.backToFirstStep( PID_Review_And_Submit);
            $( '#member-details #personal-title' ).focus();
            $wnd.document.getElementById('member-details').scrollIntoView();
            options.memberJoin.clearPage2AndPage3();
            FSSWEB.finSynAPI.analytics.setCustomVirtualPageView('fss:secure:join:member-details');
        });

        $('#review-and-submit').on('click', '.contact-details-summary a',function(e){
            e.preventDefault();
            FSSWEB.finSynAPI.newWizard.backToFirstStep( PID_Review_And_Submit );
            $( '#member-details #contact-phone-number' ).focus();
            $wnd.document.getElementById('contact-details').scrollIntoView();
            options.memberJoin.clearPage2AndPage3();
            FSSWEB.finSynAPI.analytics.setCustomVirtualPageView('fss:secure:join:member-details');
        });

        $('#review-and-submit').on('click', '.tax-file-summary a',function(e){
            e.preventDefault();
            FSSWEB.finSynAPI.newWizard.backToFirstStep( PID_Review_And_Submit );
            $( '#member-details #tfn-label' ).focus();
            $wnd.document.getElementById('tfn-details').scrollIntoView();
            options.memberJoin.clearPage2AndPage3();
            FSSWEB.finSynAPI.analytics.setCustomVirtualPageView('fss:secure:join:member-details');
        });

        $( '#review-and-submit .reviewTerms1Checkbox' ).change(
                function () {
                    if ( this.checked ) {
                        $( '#review-and-submit .reviewTerms1Container' ).removeClass( 'termConditionError' );
                    }
                } );

        $( '#review-and-submit .reviewTerms2Checkbox' ).change(
                function () {
                    if ( this.checked ) {
                        $( '#review-and-submit .reviewTerms2Container' ).removeClass( 'termConditionError' );
                    }
                } );

    };

    options.memberJoin.clearPage2AndPage3 = function() {
        $('#pwd').val('');
        $('#pwd').triggerHandler('keyup.passwordstrength');
        $('#confirm-pwd').val('');
        $('#confirm-pwd').triggerHandler('keyup.passwordstrength');
        options.memberJoin.ractive.$eb.trigger( 'MemberJoin.clearVerificationFormAndPasswordForm', null );

    };

    options.memberJoin.goBack = function(panel) {
        $('.residential-address-section .qas').hide();
        $('.residential-address-section .non-qas').show();
        if($('#address-type_address-type-check').is(':checked')){
            $('.postal-address-section.fn_addressControl .qas').hide();
            $('.postal-address-section.fn_addressControl .non-qas').show();
            options.memberJoin.ractive.$eb.trigger( 'MemberJoin.memberDetails.showHideAddress2' );

        }
        FSSWEB.finSynAPI.newWizard.backToFirstStep(panel);
        options.memberJoin.clearPage2AndPage3();
        options.memberJoin.ractive.$eb.trigger( 'MemberJoin.memberDetails.showHideAddress1' );

        FSSWEB.finSynAPI.analytics.setCustomVirtualPageView('fss:secure:join:member-details');
    };

    options.memberJoin.moveToFirstError = function(){
        if($('#member-join .form-control__outer-container.dob-wrapper').hasClass('error')){
            $('#member-join .form-control__outer-container.dob-wrapper .day').addClass('mark-focus');
        }else{
            $('#member-join .form-control__outer-container.dob-wrapper .day').removeClass('mark-focus');
        }

        if($('#member-join .form-control__outer-container .mark-focus').first().attr('id') == 'personal-dob'){
            $('#member-join #personal-dob .day').focus();
        }else if($('#member-join .form-control__outer-container .mark-focus').first().attr('id') == 'personal-title'){
            $('html, body').animate({scrollTop: $('#personal-details .title').offset().top
            }, 500);
        } else {
            $('#member-join .form-control__outer-container .mark-focus' ).first().focus();
        }

    };

    options.memberJoin.passwordVerifyFormMoveToFirstError = function(){
        $('#member-join .form-control__outer-container .mark-focus').first().focus();
        if(!$('#pwd').hasClass('mark-focus')&&!$('#confirm-pwd').hasClass('mark-focus')){
            var isCriteriaInvalid = false;
            $('.password-strength-item').each(function(key, element){
                if(!element.classList.contains('valid')){
                    isCriteriaInvalid = true;
                }
            } );
            if(isCriteriaInvalid) {
                $( '#pwd' ).focus();
            }else{
                $('#confirm-pwd').focus();
            }
        }

    };

    options.memberJoin.step1 = function(e) {
        e.preventDefault();
        var $eb = options.memberJoin.ractive.$eb;

        //logic to populate
       //$wnd.FSSWEB.finSynAPI.newWizard.nextStepFrom( PID_New_Password);
        if($.trim($('.day').val()) == ''&&$.trim($('.month').val()) == ''&&$.trim($('.year').val()) == ''){
            options.data.memberJoinForm.dateOfBirth.setValue('');
        }else {
            options.data.memberJoinForm.dateOfBirth.setValue( $( '.day' ).val() + '/' + $( '.month' ).val() + '/' + $( '.year' ).val() );
        }


        FSSWEB.finSynAPI.flowforms.startSpinner();
        var cleanup = function () {
            $eb.off( validationRemover );
            $eb.off( successRemover );
            $eb.off( failedRemover );
        };
        var validationRemover = $eb.on( 'MemberJoin.memberDetails.validationFailed', function () {
            FSSWEB.finSynAPI.flowforms.stopSpinner();
            cleanup();

            options.memberJoin.moveToFirstError();
        } );
        var failedRemover = $eb.on( 'MemberJoin.verifyContact.failed', function () {
            FSSWEB.finSynAPI.flowforms.stopSpinner();
            $( '#tokenSentToSmsMsg' ).hide();
            $( '#tokenSentToEmailMsg' ).hide();
            cleanup();

            options.memberJoin.moveToFirstError();
        } );
        var successRemover = $eb.on( 'MemberJoin.memberDetails.success', function () {
            FSSWEB.finSynAPI.flowforms.stopSpinner();
            //FSSWEB.finSynAPI.flowforms.nextPanel();
            cleanup();
            $eb.trigger( 'MemberJoin.verifyContact.sendToken', null );
            FSSWEB.finSynAPI.newWizard.nextStepFrom( PID_Member_Details );
            FSSWEB.finSynAPI.analytics.setCustomVirtualPageView('fss:secure:join:verify-contact-details');
        } );

        //sending an event into eventBus
        $eb.trigger( 'MemberJoin.memberDetails.continue', null );

    };

    options.memberJoin.step2 = function() {

        var $eb = options.memberJoin.ractive.$eb;

        FSSWEB.finSynAPI.flowforms.startSpinner();
        var cleanup = function () {
            $eb.off( validationRemover );
            $eb.off( successRemover );
        };
        var validationRemover = $eb.on( 'MemberJoin.verifyContact.validationFailed', function () {
            FSSWEB.finSynAPI.flowforms.stopSpinner();
            cleanup();
            $('#otp').focus();
        } );
        var successRemover = $eb.on( 'MemberJoin.verifyContact.success', function () {
            FSSWEB.finSynAPI.flowforms.stopSpinner();
            //FSSWEB.finSynAPI.flowforms.nextPanel();
            FSSWEB.finSynAPI.newWizard.nextStepFrom( PID_Verify_Details );
            FSSWEB.finSynAPI.analytics.setCustomVirtualPageView('fss:secure:join:create-new-password');
            cleanup();

        } );

        //sending an event into eventBus
        $eb.trigger( 'MemberJoin.verifyContact.continue', null );


    };

    options.memberJoin.step3 = function() {

        var $eb = options.memberJoin.ractive.$eb;

        FSSWEB.finSynAPI.flowforms.startSpinner();
        var cleanup = function () {
            $eb.off( validationRemover );
            $eb.off( successRemover );
        };
        var validationRemover = $eb.on( 'MemberJoin.addPassword.validationFailed', function () {
            FSSWEB.finSynAPI.flowforms.stopSpinner();
            options.memberJoin.passwordVerifyFormMoveToFirstError();
            cleanup();
        } );
        var successRemover = $eb.on( 'MemberJoin.addPassword.success', function () {
            FSSWEB.finSynAPI.flowforms.stopSpinner();
            //FSSWEB.finSynAPI.flowforms.nextPanel();
            FSSWEB.finSynAPI.newWizard.nextStepFrom( PID_New_Password );
            FSSWEB.finSynAPI.analytics.setCustomVirtualPageView('fss:secure:join:review-and-submit');
            cleanup();

        } );

        //sending an event into eventBus
        $eb.trigger( 'MemberJoin.addPassword.continue', null );




    };

    options.memberJoin.step4 = function(e) {

        var $eb = options.memberJoin.ractive.$eb;
        e.preventDefault();
        $('#review-and-submit .reviewTerms1Container').removeClass('termConditionError');
        $('#review-and-submit .reviewTerms2Container').removeClass('termConditionError');
        if(!$('#review-and-submit .error-banner').hasClass('hidden')){
            $('#review-and-submit .error-banner').addClass('hidden');
        }
        var isterm1Checked = $('#review-and-submit .reviewTerms1Checkbox').is(':checked');
        var isterm2Checked = $('#review-and-submit .reviewTerms2Checkbox').is(':checked');
        if(!isterm1Checked||!isterm2Checked){
            $('#review-and-submit .error-banner').removeClass('hidden');
            if(!isterm1Checked) {
                $( '#review-and-submit .reviewTerms1Container' ).addClass( 'termConditionError' );
            }
            if(!isterm2Checked) {
                $('#review-and-submit .reviewTerms2Container').addClass('termConditionError');
            }

            return;
        }

        var cleanup = function () {
            $eb.off( failedRemover );
            $eb.off( validationRemover );
        };
        var validationRemover = $eb.on( 'MemberJoin.summaryPage.validationFailed', function () {
            FSSWEB.finSynAPI.pageSpinner.stop();
            cleanup();
        } );
        var failedRemover = $eb.on( 'MemberJoin.summaryPage.failed', function () {
            FSSWEB.finSynAPI.pageSpinner.stop();
            cleanup();
        } );

        //FSSWEB.finSynAPI.analytics.setProcessComplete('ssc', 'join',null);

        //Sending an final submission into event Bus
        $eb.trigger( 'MemberJoin.summaryPage.continue', null );



    };

    options.complete = function() {
        var ractive = this;
        var $eb = ractive.$eb;
        var $ = $wnd.$;

        options.memberJoin.ractive = this;

        options.data.memberJoinForm.residentialLine1.setVisible( false );
        options.data.memberJoinForm.residentialLine2.setVisible( false );
        options.data.memberJoinForm.residentialState.setVisible( false );
        options.data.memberJoinForm.residentialPostcode.setVisible( false );
        options.data.memberJoinForm.residentialSuburb.setVisible( false );
        options.data.memberJoinForm.line1.setVisible( false );
        options.data.memberJoinForm.line2.setVisible( false );
        options.data.memberJoinForm.state.setVisible( false );
        options.data.memberJoinForm.postcode.setVisible( false );
        options.data.memberJoinForm.suburb.setVisible( false );
        options.data.memberJoinForm.residentialSearchAddress.setVisible( true );


        FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'join',null);
        FSSWEB.finSynAPI.analytics.setCustomVirtualPageView('fss:secure:join:member-details');

        //intilize wizard
        $wnd.FSSWEB.finSynAPI.newWizard.init();
        FSSWEB.finSynAPI.wizard.create();

        options.memberJoin.registerEventListeners($eb);

    }
});
