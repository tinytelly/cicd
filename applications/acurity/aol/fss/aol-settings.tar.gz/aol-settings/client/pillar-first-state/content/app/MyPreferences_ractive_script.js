(function( options ) {

    options.complete = function() {
        //jquery binding
        var $ = $wnd.$
        var $ractive = this;
        var $eb = $ractive.$eb;
        var FSSWEB = $wnd.FSSWEB;


        var allMarketingPreferenesChecked = true;
        FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'update-communication',null);

        //$('div.ctrl-holder.fn_checkAll.styled-labels > ul > li input ').each(function(){
        $('div.ctrl-holder.fn_checkAll input ').each(function(){
            if($(this)[0].id != 'comms-channel_comms-adv-all' && $(this)[0].checked == false){
                allMarketingPreferenesChecked = false;
            }
        });
        if(allMarketingPreferenesChecked){
            $('#comms-channel_comms-adv-all')[0].checked =true;
        }

        $( '.communicationPreferencesForm .formpanel__savelink ' ).on( 'click', function( e ) {


        } );


        $( '.marketingPreferencesForm .formpanel__savelink ' ).on( 'click', function( e ) {
            (function() {
                var cleanup = function() {
                    $eb.off( failureHandle );
                    $eb.off( successHandle );
                    $eb.off( cancelHandle );
                };
                var successHandle = $eb.on( "MyPreferences.updateMarketingPreferences.success", function ( eventName, data ) {
                    options.data.rc.updatedMarketingPreferences= "success";
                    $ractive.update( 'rc.updatedMarketingPreferences' );
                    options.data.rc.updatedCommunicationPreferences= "";
                    $ractive.update( 'rc.updatedCommunicationPreferences' );
                    //FSSWEB.finSynAPI.pageSpinner.stop();
                } );
                var failureHandle = $eb.on( 'MyPreferences.updateMarketingPreferences.failure', function( eventName, data ) {
                    options.data.rc.updatedMarketingPreferences= "failure";
                    options.data.rc.errorMessage = "We were unable to update your preferences at this time. Please try again later. If you continue to experience this problem, please call us on 1300 650 873.";
                    $ractive.update( 'rc.updatedMarketingPreferences' );
                    options.data.rc.updatedCommunicationPreferences= "";
                    $ractive.update( 'rc.updatedCommunicationPreferences' );
                    //FSSWEB.finSynAPI.pageSpinner.stop();
                    cleanup();
                } );
                var cancelHandle = $eb.on( 'MyPreferences.updateMarketingPreferences.cancel', function( eventName, data ) {
                    //FSSWEB.finSynAPI.pageSpinner.stop();
                    cleanup();
                } );
            })();

            (function() {
                var cleanup = function() {
                    $eb.off( failureHandle );
                    $eb.off( successHandle );
                    $eb.off( cancelHandle );
                };
                var successHandle = $eb.on( "MyPreferences.updateCommunicationPreferences.success", function ( eventName, data ) {
                    options.data.rc.updatedCommunicationPreferences= "success";
                    $ractive.update( 'rc.updatedCommunicationPreferences' );
                    options.data.rc.updatedMarketingPreferences= "";
                    $ractive.update( 'rc.updatedMarketingPreferences' );
                    FSSWEB.finSynAPI.analytics.setProcessComplete('ssc', 'update-communication',null);
                    //FSSWEB.finSynAPI.pageSpinner.stop();
                } );
                var failureHandle = $eb.on( 'MyPreferences.updateCommunicationPreferences.failure', function( eventName, data ) {
                    options.data.rc.updatedCommunicationPreferences= "failure";
                    $ractive.update( 'rc.updatedCommunicationPreferences' );
                    options.data.rc.updatedMarketingPreferences= "";
                    $ractive.update( 'rc.updatedMarketingPreferences' );
                    //FSSWEB.finSynAPI.pageSpinner.stop();
                    cleanup();
                } );
                var cancelHandle = $eb.on( 'MyPreferences.updateCommunicationPreferences.cancel', function( eventName, data ) {
                    //FSSWEB.finSynAPI.pageSpinner.stop();
                    cleanup();
                } );
            })();

            //FSSWEB.finSynAPI.pageSpinner.start();
            $eb.trigger( "MyPreferences.updatePreferencesCombined", null );
        } );


        //$('div.ctrl-holder.fn_checkAll.styled-labels > ul > li input ').on( 'click', function( e ) {
        $('div.ctrl-holder.fn_checkAll input').on( 'click', function( e ) {
            if($(this)[0].id == 'comms-channel_comms-adv-all'){
                if($(this)[0].checked == true){
                    $('div.ctrl-holder.fn_checkAll input ').each(function(){
                        $(this)[0].checked = true;
                        $(this).change();
                    });
                }else if($(this)[0].checked == false){
                    $('div.ctrl-holder.fn_checkAll input ').each(function(){
                        $(this)[0].checked = false;
                        $(this).change();
                    });
                }
            } else{
                if($(this)[0].checked == false){
                    $('#comms-channel_comms-adv-all')[0].checked =false;
                }else if($(this)[0].checked == true){
                    var allcheckBoxesChecked = true;
                    $('div.ctrl-holder.fn_checkAll input ').each(function(){
                        if($(this)[0].id != 'comms-channel_comms-adv-all' && $(this)[0].checked ==false ){
                            allcheckBoxesChecked = false;
                        }
                    });
                    if(allcheckBoxesChecked){
                        $('#comms-channel_comms-adv-all')[0].checked =true;
                    }
                }
            }
        });


        function populateRactive( id ) {
            if(null!=ractivedata.marketingPreferencesForm){

            }
        }

    }
});