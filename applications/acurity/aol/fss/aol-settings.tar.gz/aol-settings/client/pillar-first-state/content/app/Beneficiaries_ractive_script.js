(function ( options ) {
    var window = $wnd;
    var $ = $wnd.$;
    var FSSWEB = $wnd.FSSWEB;

    var legalRepText = "Legal Personal Representative";

    options.data.isLegalRep = function( value ) {
        return value == legalRepText;
    }

    options.complete = function () {
        var $ractive = this;
        var $eb = $ractive.$eb;
        var dependantsValidationForm = options.data.dependantsValidationForm;
        var nonBindingDependants = options.data.nonBindingDependants;

        options.data.hintTotal = "";
        var updateHintMessage = function() {
            var total = 0;
            var isError = false;
            $( '.beneficiary-edit-section .percentageInput' ).each( function( e ) {
                var percentage = $( this ).val().split( '%' )[0];

                if( isError || percentage == null || percentage == '' || percentage == undefined ) {
                    return ;  //skip calcuation.
                }

                var value = parseFloat( percentage );
                if ( !isNaN( value ) ) {
                    total += value;
                } else {
                    isError = true;
                }

                if( value <= 0 || value > 100) {
                    isError = true;
                }

            });

            if( isError ) {
                $ractive.set( 'hintTotal', "User Error" );
            } else {
                $ractive.set( 'hintTotal', total.toFixed(0) + "%" );
            }
        }

        function updateFieldVisibility( value, form ) {
            if ( legalRepText == value ) {
                form.benTitle.setVisible( false );
                form.benGivenNames.setVisible( false );
                form.benSurname.setVisible( false );
                form.benGender.setVisible( false );
                form.benBirthDate.setVisible( false );
            } else {
                form.benTitle.setVisibleToDefault();
                form.benGivenNames.setVisibleToDefault();
                form.benSurname.setVisibleToDefault();
                form.benGender.setVisibleToDefault();
                form.benBirthDate.setVisibleToDefault();
            }
        }

        function updateNonBindingDependants() {
            $( '.beneficiary-edit-section .benRelationship select' ).each( function ( index, selectEle ) {
                var $selectEle = $( selectEle )
                var index = $selectEle.attr( 'id' ).split( '-' )[2];
                var value = $selectEle.val();
                var form = options.data.nonBindingDependants[index];
                updateFieldVisibility( value, form );
            } );
        }


        $( '#non-binding-beneficiaries' ).on( 'click.finsyn', '.editNonBinding', function( e ) {
            var ready = {
                "event": "Beneficiaries.dependants.nonbinding.edit.ready",
                "handler": function ( event, data ) {
                    nonBindingDependants.clearValidation();
                    dependantsValidationForm.clearValidation();
                    updateHintMessage();
                }
            }
            var update = {
                "event": "Beneficiaries.dependants.nonbinding.edit.needUpdate",
                "handler": function ( event, data ) {
                    FSSWEB.update( $( '#non-binding-beneficiaries' ) );
                    updateHintMessage();
                }
            }
            FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'update-beneficiaries',null);
            $eb.once( ready, update );
            $eb.trigger( 'Beneficiaries.dependants.nonbinding.edit' );
        });

        $( '#edit-beneficiaries' ).on( 'click.finsyn', '.beneficiary-remove', function( e ) {
            var removed = {
                "event" : "Beneficiaries.dependants.nonbinding.removed",
                "handler" : function( event, data ) {
                    FSSWEB.update( $( '#non-binding-beneficiaries' ) );
                    //$( '#select-0022-0' ).focus();
                    //$($( '.benRelationship ' )[0]).addClass( 'input--active' );
                    updateHintMessage();
                }
            };
            $eb.once( removed );
            $eb.trigger( 'Beneficiaries.dependants.nonbinding.remove', {"index": $( e.currentTarget ).attr( 'data-aol-dependant-index' )} );
        });

        $( '#edit-beneficiaries' ).on( 'click.finsyn', '.addMoreNonBinding', function( e ) {
            var added = {
                "event" : "Beneficiaries.dependants.nonbinding.added",
                "handler" : function( event, data ) {
                    FSSWEB.update( $( '#non-binding-beneficiaries' ) );
                }
            }
            $eb.once( added );
            $eb.trigger( 'Beneficiaries.dependants.nonbinding.add', null );
        } );

        $( '.form-theme-magenta .saveButton' ).on( 'click.finsyn', function( e ) {
            nonBindingDependants.clearValidation();
            dependantsValidationForm.clearValidation();
            if( nonBindingDependants.validate() && dependantsValidationForm.validate() ) {
                var updated = {
                    "event" : "Beneficiaries.dependants.nonbinding.update.submitted",
                    "handler" : function( event, data ) {
                        FSSWEB.finSynAPI.analytics.setProcessComplete('ssc', 'update-beneficiaries',null);
                        window.location = '#Beneficiaries';
                    }
                }
                var failed = {
                    "event" : "Beneficiaries.dependants.nonbinding.update.failed",
                    "handler" : function( event, data ) {
                        console.error( 'Beneficiaries update failed. Refresh page for now.' )
                        //window.location = '#Beneficiaries';
                    }
                }
                $eb.once( updated, failed );
                $eb.trigger( 'Beneficiaries.dependants.nonbinding.update.submit', null );
            }
        }  );

        $( '.form-theme-magenta .cancelButton' ).on( 'click.finsyn', function( e ) {
            var dataModel = options.data;

            var cancel = {
                "event" : "Beneficiaries.dependants.nonbinding.update.cancelled",
                "handler" : function( event, data ) {
                    FSSWEB.update( $( '#non-binding-beneficiaries' ) );
                    updateNonBindingDependants();
                }
            }
            $eb.once( cancel )
            $eb.trigger( 'Beneficiaries.dependants.nonbinding.update.cancel', null );

        }  );

        $( '#edit-beneficiaries' ).on( 'focus', '.beneficiary-edit-section input, .beneficiary-edit-section select', function( e ) {
            $( '.beneficiary-edit-section .help.percentage-total' ).each( function() {
                $( this ).addClass( 'js-hidden' )
            });

            var name = $( e.currentTarget ).attr( 'name' );
            var split = name.split( '-' );
            var index = split[split.length - 1];
            $( '.beneficiary-edit-section-' + index + ' .help.percentage-total').removeClass( 'js-hidden' );
        });

        $( '#edit-beneficiaries' ).on( 'change', '.beneficiary-edit-section .percentageInput', function( e ) {
             updateHintMessage();
        } );

        $( '#edit-beneficiaries' ).on( 'change', '.beneficiary-edit-section .benRelationship select', function( e ) {
            var selectEle = $( e.currentTarget );
            var index = selectEle.attr( 'id' ).split( '-' )[2];
            var value = selectEle.val();
            var form = options.data.nonBindingDependants[index];
            updateFieldVisibility( value, form );
            if( legalRepText == value ) {
                form.benTitle.setValue( "" );
                form.benGivenNames.setValue( "" );
                form.benGender.setValue( "" );
                form.benBirthDate.setValue( "" );
                form.benSurname.setValue( legalRepText );
            } else {
                if( form.benSurname.getValue() == legalRepText ) {
                    form.benSurname.setValue( "" );
                }
            }
        } );

        $( '#edit-beneficiaries' ).on( 'keypress', '.beneficiary-edit-section .benPercentage input', function( e ) {
            var charCode = (e.which) ? e.which : event.keyCode

            if (charCode == 37) {
                var percentage = $( this ).val();
                if(percentage.indexOf('%') > -1) {
                    return false;
                }
            }

            if (charCode > 31 && (charCode != 37 &&(charCode < 48 || charCode > 57)))
                return false;

            return true;
        });

        //init the screen.
        updateHintMessage();
        updateNonBindingDependants();
    }
});