(function ( options ) {

    options.sections.profile = {};

    options.sections.profile.complete = function( scope ) {

    }
});