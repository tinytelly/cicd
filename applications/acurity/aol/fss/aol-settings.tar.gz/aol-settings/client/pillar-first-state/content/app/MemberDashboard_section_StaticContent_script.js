(function ( options ) {

    options.sections.staticContent = {};

    options.sections.staticContent.complete = function( scope ) {

    }
});