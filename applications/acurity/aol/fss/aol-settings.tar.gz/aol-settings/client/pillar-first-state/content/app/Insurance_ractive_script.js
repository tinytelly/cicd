(function( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;
    //options.data.$place = {};


    FinSyn.console.debug("DEBUG: Insurance_ractive_script setup");

    options.complete = function () {
        var ractive = this;
        var $eb = ractive.$eb;

        //$( '#select-000.full .select-effective-date' ).on( 'change', function ( e ) {
        //    console.log("DEBUG: Insurance, dateselector changed");
        //    //$eb.trigger( 'Insurance.InsuranceHistoryDateSelectorForm.Refresh', null );
        //});


        // works $( 'a.fancy.c-download-links__link.downloadpdf' ).on( 'click', function () {
        // works $( '.m-insurance__downloads .downloadpdf' ).on( 'click', function () {
        //$( 'a.c-download-links__link.downloadpdf' ).on( 'click', function () {
        //    $eb.trigger( "System.exportPDF", null );
        //} );
        $('.InsurancePlace').on('click','a[href="#TalInsuranceUpdate"]', function(event){
            FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'insurance',null);
        });


    }
});
