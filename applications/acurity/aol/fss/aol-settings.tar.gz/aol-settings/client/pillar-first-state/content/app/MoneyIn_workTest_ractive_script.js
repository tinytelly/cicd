(function ( options ) {
    var window = $wnd;
    var $ = $wnd.$;
    var FSSWEB = $wnd.FSSWEB;
    var dataModel = options.data;

    options.complete = function () {
        var $ractive = this;
        var $eb = $ractive.$eb;

        $( '#eligibility-nav' ).on( 'click', '.passWorkTest', function () {
            var updated = {
                "event": 'MoneyIn.workTest.eligible.submit.updated',
                "handler": function () {
                    window.location = '#MoneyIn';
                }
            };
            var failed = {
                "event": "MoneyIn.workTest.eligible.submit.failed",
                "handler": function ( event, data ) {
                    console.error( 'MondayIn WorkTest update failed. Refresh page for now.' )
                    //window.location = '#MoneyIn';
                }
            }
            $eb.once( updated, failed );
            $eb.trigger( 'MoneyIn.workTest.eligible.submit' );
        } );
    }
});