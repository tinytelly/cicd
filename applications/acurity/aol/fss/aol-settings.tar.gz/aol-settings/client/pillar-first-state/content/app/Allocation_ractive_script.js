(function( options ) {
    options.data.showInvestmentOption = function( investmentOptionMetaData,investmentOption,currentTab) {
        if(options.data.checkRowCondition(investmentOption,currentTab)){
            return true;
        }
        return false;
    };

    options.data.showInvestmentSubSection = function( investmentOptions, list , currentTab) {
        var show = false;
        for( var i=0; i< investmentOptions.length; i++ ) {
            var assetCode = investmentOptions[i].investmentOptionId;
            if (list != undefined) {
                var item = list[assetCode];
                if (options.data.checkSubSectionCondition(item,currentTab)) {
                    show = true;
                    break;
                }
            }
        }
        return show;
    };

    options.data.showAssetClassSubSection= function( subHeadingName, list , currentTab) {
        if(subHeadingName =='Direct invest'){
            /*var mdisStatus = options.data.rc.mdisStatus;
            if(null!=mdisStatus && (mdisStatus == 'D' || mdisStatus == 'R')){
            }*/
            if(null!=list && undefined !=list ){
                for( var i=0; i< list.rows.length; i++ ) {
                    if(null!=list.rows[i] && list.rows[i].assetClassId.getValue()=='asset-19' && null!=list.rows[i].currentValue &&
                        list.rows[i].currentValue.getStrongValue()!=0){
                        return true;
                    }
                }
            }
            return false;
        }
       return true;
    };

    options.data.checkSubSectionCondition = function(currentObj,currentTab){
        if(currentTab == undefined){
            return false;
        }
        if(currentTab=='CurrentBalance'){
            if (currentObj != undefined && currentObj.marketValue.getValue() != '') {
                return true;
            }
        }else if(currentTab == 'FutureContributions'){
            if (currentObj != undefined && currentObj.profilePercent.getStrongValue() > 0) {
                return true;
            }
        }else if(currentTab == 'PensionDrawDownPercentage'){
            if (currentObj != undefined && currentObj.profileDrawDown.getStrongValue() > 0) {
                return true;
            }
        }else if(currentTab == 'PensionDrawDownPriority'){
            if (currentObj != undefined && currentObj.profileOrderNumber.getStrongValue() > 0) {
                return true;
            }
        }else if(currentTab == 'PensionDrawDownOther'){
            if (currentObj != undefined && currentObj.profilePercent.getStrongValue() > 0) {
                return true;
            }
        }
    };

    options.data.checkRowCondition = function(currentObj,currentTab){
        if(currentTab == undefined){
            return false;
        }
        if(currentTab=='CurrentBalance'){
            if(currentObj!=undefined && currentObj.marketValue.getValue() != '' ){
                return true;
            }
        }else if(currentTab == 'FutureContributions'){
            if (currentObj != undefined && currentObj.profilePercent.getFormattedValue() != '0.00%' && currentObj.profilePercent.getFormattedValue() != '' ) {
                return true;
            }
        }else if(currentTab == 'PensionDrawDownPercentage'){
            if (currentObj != undefined && currentObj.profileDrawDown.getFormattedValue() != '0.00%' && currentObj.profileDrawDown.getFormattedValue() != '' ) {
                return true;
            }
        }else if(currentTab == 'PensionDrawDownPriority'){
            if (currentObj != undefined && currentObj.profileOrderNumber.getFormattedValue() != '' ) {
                return true;
            }
        }else if(currentTab == 'PensionDrawDownOther'){
            if (currentObj != undefined && currentObj.profileDrawDown.getFormattedValue() != '0.00%' && currentObj.profileDrawDown.getFormattedValue() != '' ) {
                return true;
            }
        }

    };

    options.data.isSuspendedInvestment = function( portfolioHoldingsList ,assetCode) {
        if(null!=portfolioHoldingsList[assetCode] && undefined!=portfolioHoldingsList[assetCode]){
            var investmentOptionAssetCode = portfolioHoldingsList[assetCode].uniqueKey.getValue();
            if(undefined!=investmentOptionAssetCode && investmentOptionAssetCode.indexOf("_susp")>=0){
                return true;
            }
        }
        return false;
    };

    options.data.isSuspendedInvestmentOptionPresent= function( portfolioHoldingsList ,assetCode) {
        if(null!=portfolioHoldingsList[assetCode] && undefined!=portfolioHoldingsList[assetCode]){
            var suspendedAssetCode = assetCode+"_susp";
            if(null!=portfolioHoldingsList[suspendedAssetCode] && undefined!=portfolioHoldingsList[suspendedAssetCode]){
                return true;
            }
        }
        return false;
    };

    options.data.getInvestmentOption = function( portfolioHoldingsList ,assetCode) {
        return portfolioHoldingsList[assetCode];
    };

    options.data.getAssetClassInfo = function( assetAllocationLegendList ,assetCode) {
        if(assetAllocationLegendList!= undefined){
            return assetAllocationLegendList[assetCode];
        }
        return null;
    };

    //This is generally to retrieve data for a single section
    options.data.getAssetClassData = function( assetClasses, list ) {
        var totalAllocation = 0;
        var totalPecentage = 0;
        var color;
        for( var i=0; i< assetClasses.length; i++ ) {
            color =  assetClasses[i].color;
            var assetCode = assetClasses[i].assetClassId;
            if(list !=undefined) {
                var item = list[assetCode];
                if (item != undefined) {
                    var allocation = Number(item.currentValue.getStrongValue());
                    totalAllocation += allocation;
                    var percentage = Number(item.percentage.getStrongValue())
                    totalPecentage += percentage;
                }
            }else{
                break;
            }
        }
        //totalAllocation = totalAllocation.toFixed(2);
        //totalPecentage = totalPecentage.toFixed(2);
        return {'totalPercentage':round(totalPecentage,1) ,'totalAllocation': totalAllocation,'color':color};
    };

    function round(value, precision) {
        var multiplier = Math.pow(10, precision || 0);
        var val = (Math.round(value * multiplier) / multiplier).toFixed(1);
        return val;
    }


    options.complete = function() {
        //jquery binding
        var $ = $wnd.$
        var $ractive = this;
        var $eb = $ractive.$eb;
        var FSSWEB = $wnd.FSSWEB;
    }
});