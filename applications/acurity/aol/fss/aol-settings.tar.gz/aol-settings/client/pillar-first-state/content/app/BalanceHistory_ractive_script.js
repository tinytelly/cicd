(function ( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;

    options.balanceHistory = {};

    options.balanceHistory.getStartDate = function( graphObj ) {
        var periods = graphObj.periods;
        return options.balanceHistory.toAcurityDate( periods[0].start );
    };

    options.balanceHistory.toAcurityDate = function( date ) {
        var tokens = date.split( "-" );
        if ( tokens.length !== 3 ) {
            return date;
        }
        return tokens[2] + "/" + tokens[1] + "/" + tokens[0];
    };

    options.complete = function () {
        var ractive = this;
        var $eb = ractive.$eb;
        var $ = $wnd.$;

        // construct data
        var balanceHistoryDetails = ractive.get( "balanceHistoryDetails" );
        var graphObj = JSON.parse( balanceHistoryDetails.graphJson );
        balanceHistoryDetails.startDate = options.balanceHistory.getStartDate( graphObj );

        // render UI
        ractive.set( "balanceHistoryDetails.startDate", balanceHistoryDetails.startDate );

        // render graph
        var graph = new FSSWEB.chartBalanceHistory.Chart( ".aolc-balanceHistory-graph" );
        graph.render( [ graphObj ] );

        // render content slot
        $( "#aoli-cs-employerContribution" ).html( balanceHistoryDetails.employerContribution );
        $( "#aoli-cs-additionalPostTax" ).html( balanceHistoryDetails.additionalPostTax );
        $( "#aoli-cs-salarySacrifice" ).html( balanceHistoryDetails.salarySacrifice );
        $( "#aoli-cs-rolloversIn" ).html( balanceHistoryDetails.rolloversIn );
        $( "#aoli-cs-withdrawals" ).html( balanceHistoryDetails.withdrawals );
        $( "#aoli-cs-regularPensionPayments" ).html( balanceHistoryDetails.regularPensionPayments );
    }
});