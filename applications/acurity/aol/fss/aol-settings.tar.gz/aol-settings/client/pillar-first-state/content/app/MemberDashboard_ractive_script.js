(function ( options ) {
    var scope = {};

    scope.window = $wnd;
    scope.$ = $wnd.$;
    scope.FinSyn = $wnd.FinSyn;
    scope.FSSWEB = $wnd.FSSWEB;

    options.sections = {};

    options.complete = function () {
        scope.ractive = this;
        scope.$eb = this.$eb;
        scope.getData = function( key ) {
            return scope.ractive.get( key );
        };
        scope.setData = function( key, value ) {
            scope.ractive.set( key, value );
        };
        scope.setPlainObjectContentData = function( data ) {
            scope.ractive.set( data.id, JSON.parse(data.content) );
        };

        var sections = options.sections;
        for ( var sectionName in sections ) {
            if ( sections.hasOwnProperty( sectionName ) ) {
                sections[ sectionName ].complete( scope );
            }
        }

        scope.$eb.trigger( "MemberDashboard.ui.complete", null );
    };
});