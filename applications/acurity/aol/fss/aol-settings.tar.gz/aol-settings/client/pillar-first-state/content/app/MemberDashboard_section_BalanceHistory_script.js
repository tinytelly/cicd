(function ( options ) {

    options.sections.balanceHistory = {};

    options.sections.balanceHistory.currentSelected = {};

    options.sections.balanceHistory.select = function( scope, selectedId ) {
        var detailsOrDashboard = scope.getData( 'balanceHistoryDashboard' );
        if ( selectedId !== 'all' ) {
            detailsOrDashboard = detailsOrDashboard.detailsMap[ selectedId ];
        }

        var currentSelected = options.sections.balanceHistory.currentSelected;
        currentSelected.id = selectedId;
        currentSelected.balance = detailsOrDashboard.currentBalance;
        currentSelected.benefitCategory = detailsOrDashboard.benefitCategory;
        currentSelected.zeroBalance = detailsOrDashboard.zeroBalance;
        currentSelected.insurance = detailsOrDashboard.insurance;
        currentSelected.graphObjs = detailsOrDashboard.graphObjs;
        currentSelected.period = detailsOrDashboard.period;
        currentSelected.fundCode = detailsOrDashboard.fundCode;
        currentSelected.memberNumber = detailsOrDashboard.memberNumber;

        scope.$eb.trigger( "MemberDashboard.ui.putRenderContext", {
            selectedBalanceHistoryFundCode: detailsOrDashboard.fundCode != null ? detailsOrDashboard.fundCode : "",
            selectedBalanceHistoryMemberNumber: detailsOrDashboard.memberNumber != null ? detailsOrDashboard.memberNumber : ""
        } );
        scope.setData( "selectedBalanceHistory", currentSelected );
        options.sections.balanceHistory.graph.render( currentSelected.graphObjs );
    };

    options.sections.balanceHistory.formatDate = function( date, monthOnly ) {
        var monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];
        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();
        return (monthOnly ? "" : day + " " ) + monthNames[monthIndex] + " " + year;
    };

    /***Forat date like 02/02/2019***/
    options.sections.balanceHistory.formatDateToNumeric = function( date, monthOnly ) {
        var day = date.getDate();
        var month = date.getMonth()+1;
        var year = date.getFullYear();
        if (day < 10) {
            day = '0' + day;
        }
        if (month < 10) {
            month = '0' + month;
        }
        return (monthOnly ? "" : day + "/" ) + month + "/" + year;
    };

    options.sections.balanceHistory.parseData = function( dataContent ) {
        var balanceHistoryDashboard = JSON.parse( dataContent );
        var startDate;
        var graphObjs = [];
        var benefitCategory;
        var detailsMap = balanceHistoryDashboard.detailsMap;
        for ( var detailsKey in detailsMap ) {
            if ( !detailsMap.hasOwnProperty( detailsKey ) ) {
                continue;
            }
            var details = detailsMap[ detailsKey ];
            var graphObj = JSON.parse( details.graphJson );
            var graphStartDate = graphObj.periods != null && graphObj.periods.length > 0 ? new Date( graphObj.periods[0].start ) : undefined;
            details.period = options.sections.balanceHistory.createPeriod( details, graphStartDate );
            details.graphObjs = [ graphObj ];
            if ( graphStartDate !== undefined && (startDate === undefined || startDate.getTime() > graphStartDate.getTime()) ) {
                startDate = graphStartDate;
            }
            graphObjs.push( graphObj );
            if ( benefitCategory === undefined ) {
                // always get the first one for "all" selection
                benefitCategory = details.benefitCategory;
            }
        }
        balanceHistoryDashboard.period = options.sections.balanceHistory.createPeriod( balanceHistoryDashboard, startDate );
        balanceHistoryDashboard.graphObjs = graphObjs;
        balanceHistoryDashboard.currentBalance = balanceHistoryDashboard.totalBalance;
        balanceHistoryDashboard.benefitCategory = benefitCategory;
        return balanceHistoryDashboard;
    };

    options.sections.balanceHistory.createPeriod = function( detailsOrDashboard, graphStartDate ) {
        if ( detailsOrDashboard.zeroBalance || detailsOrDashboard.insurance || graphStartDate === undefined ) {
            return "Balance at " + options.sections.balanceHistory.formatDate( new Date() );
        }
        return "Period " + options.sections.balanceHistory.formatDate(graphStartDate, true) + " - Present ("+options.sections.balanceHistory.formatDateToNumeric( new Date())+")";
    }

    options.sections.balanceHistory.complete = function( scope ) {
        scope.$eb.once({
            "event": "MemberDashboard.getClientBalanceHistoryDashboard.success",
            "handler": function ( eventName, data ) {
                // init graph
                options.sections.balanceHistory.graph = new scope.FSSWEB.chartBalanceHistory.Chart( "#aoli-balanceHistory-graph" );
                // set data
                scope.setData( data.id, options.sections.balanceHistory.parseData(data.content) );
                // select all by default
                options.sections.balanceHistory.select( scope, "all" );
                // register listener to insurance selection
                scope.ractive.on( "selectBalanceHistory", function( event, selectedId ) {
                    options.sections.balanceHistory.select( scope, selectedId );
                } );
            }
        });
    };
});
