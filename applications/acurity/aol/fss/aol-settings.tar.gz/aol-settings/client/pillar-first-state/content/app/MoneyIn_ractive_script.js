(function ( options ) {
    var window = $wnd;
    var $ = $wnd.$;
    var FSSWEB = $wnd.FSSWEB;
    var dataModel = options.data;

    options.complete = function () {
        var $ractive = this;
        var $eb = $ractive.$eb;

        $( '#directDebitSection' ).on( 'click', '.directDebitSubmit', function() {
            if( dataModel.paymentDirectDebitForm.validate() &&  dataModel.directDebitTermsAndConditionsForm.validate() ) {
                var updated = {
                    "event"   : 'MoneyIn.directDebit.update.submit.updated',
                    "handler" : function() {
                        window.location = '#MoneyIn';
                    }
                };
                var failed = {
                    "event" : "MoneyIn.directDebit.update.submit.failed",
                    "handler" : function( event, data ) {
                        console.error( 'MondayIn update failed. Refresh page for now.' )
                        //window.location = '#MoneyIn';
                    }
                }
                $eb.once( updated, failed );
                $eb.trigger( 'MoneyIn.directDebit.update.submit', null );
            }
        });

        $( '#directDebitSection' ).on( 'click', '.cancelDirectDebit', function () {
            FSSWEB.finSynAPI.modals.open( 'modal-confirm-cancel-direct-debit', function () {}, {}, '{}', {
                cancel : function() {
                    var updated = {
                        "event": 'MoneyIn.directDebit.cancel.submit.cancelled',
                        "handler": function () {
                            window.location = '#MoneyIn';
                        }
                    };
                    var failed = {
                        "event": "MoneyIn.directDebit.cancel.submit.failed",
                        "handler": function ( event, data ) {
                            console.error( 'MondayIn cancellation failed. Refresh page for now.' )
                            //window.location = '#MoneyIn';
                        }
                    }
                    //setTimeout( function() {
                        $eb.once( updated, failed );
                        $eb.trigger( 'MoneyIn.directDebit.cancel.submit', null );
                    //}, 1000 )
                }
            } );
        } );

        $( '#directDebitSection' ).on( 'click', '.directDebitCancelEditing', function() {
            var cancelled = {
                "event"   : 'MoneyIn.directDebit.cancelEditing.cancelled',
                "handler" : function() {
                    //making sure the UI is updated properly
                    $( '#directDebitSection input' ).trigger( 'fnUIChange' );
                }
            };
            $eb.once( cancelled );
            $eb.trigger( 'MoneyIn.directDebit.cancelEditing', null );
        });

        $( '#view-only-fieldset' ).on( 'click', '.editDirectDebit', function() {
            var exitVal = dataModel.paymentDirectDebitForm.bsbNumber.getValue();
            dataModel.paymentDirectDebitForm.bsbNumber.setValue( '' );
            dataModel.paymentDirectDebitForm.bsbNumber.setValue( exitVal );
            $ractive.set( 'directDebitTermsAndConditionsForm.consentCheckbox.value', 'No' );
            FSSWEB.update( $('#edit-direct-debit-section') );
        });


       // $('.MoneyIn_employer_contributions_header .download__link').on('click', function(event){
       //     console.log('money in');
       // });

        $('.MoneyInPlace').on('click','.MoneyIn_employer_contributions_header .download__link', function(event){
            FSSWEB.finSynAPI.analytics.setProcessStart('ssc', 'make-contribution',null);
        });
    }
});