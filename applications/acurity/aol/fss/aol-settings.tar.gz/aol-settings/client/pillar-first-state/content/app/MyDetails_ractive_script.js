(function ( options ) {
    options.data.isNotBlank = function ( item ) {
        if ( item != null && item.getValue() != null && item.getValue() != '' ) {
            return true;
        } else {
            return false;
        }
    };

    options.data.isBlank = function ( item ) {
        if ( item == null || item.getValue() == null || item.getValue() == '' ) {
            return true;
        } else {
            return false;
        }
    };

    //evaluate init state of workPhone and homePhone
    options.data.initHomePhoneSelected = options.data.isNotBlank( options.data.clientBasicDetailsForm.homePhone );
    options.data.initWorkPhoneSelected = options.data.isNotBlank( options.data.clientBasicDetailsForm.workPhone );

    options.complete = function () {
        //jquery binding
        var $ = $wnd.$
        var $ractive = this;
        var $eb = $ractive.$eb;
        var FSSWEB = $wnd.FSSWEB;

        var defaultPostalQAS = options.data.clientBasicDetailsForm.qasPick.getValue();
        var defaultResidentialQAS = options.data.clientBasicDetailsForm.residentialQasPick.getValue();

        $wnd.FinSyn.namespace( 'FinSyn.places.myDetails' );
        $( '#sel_country' ).on( 'change', function ( e ) {
            var value = $( e.target ).val();
            if ( value != 'Australia' ) {
                $( '#postal-address-ctrl-1' ).removeClass( 'hidden' );
                $( '#autocomplete-address-1' ).addClass( 'hidden' );
            }
        } );
        $( '#sel_country-r' ).on( 'change', function ( e ) {
            var value = $( e.target ).val();
            if ( value != 'Australia' ) {
                $( '#postal-address-ctrl-2' ).removeClass( 'hidden' );
                $( '#autocomplete-address-2' ).addClass( 'hidden' );
            }
        } );
        $( '.MyDetailsPlace' ).on( 'change', '.residentialQASPicker', function ( event ) {
            var pickerValue = event.currentTarget.value;
            if ( pickerValue == "" ) {
                event.currentTarget.value = defaultResidentialQAS;
            }

            var options = $( '.MyDetailsPlace .residentialQASAutocompleteListWrap label' ).toArray();
            for ( var i = 0; i < options.length; i++ ) {
                if ( options[i].innerHTML == pickerValue ) {
                    defaultResidentialQAS = pickerValue;
                    return;
                }
            }
            event.currentTarget.value = defaultResidentialQAS;
        } );

        $( '.MyDetailsPlace' ).on( 'change', '.postalQASPicker', function ( event ) {
            var pickerValue = event.currentTarget.value;
            if ( pickerValue == "" ) {
                event.currentTarget.value = defaultPostalQAS;
            }

            var options = $( '.MyDetailsPlace .postalQASAutocompleteListWrap label' ).toArray();
            for ( var i = 0; i < options.length; i++ ) {
                if ( options[i].innerHTML == pickerValue ) {
                    defaultPostalQAS = pickerValue;
                    return;
                }
            }
            event.currentTarget.value = defaultPostalQAS;
        } );

        //console.log($('.fn_setCancelReset'));
        $( '.MyDetailsPlace' ).on( 'click', 'a[data-show-ids="provide-tfn-form, tfn-save"]', function ( event ) {
            FSSWEB.finSynAPI.analytics.setProcessStart( 'ssc', 'provide-tfn', null );
        } );

        $( '.MyDetailsPlace' ).on( 'click', 'a[data-hide-ids="tfn-save, provide-tfn-form"]', function ( event ) {
            FSSWEB.finSynAPI.analytics.setProcessComplete( 'ssc', 'provide-tfn', null );
        } );
        $( '.MyDetailsPlace' ).on( 'click', 'a[data-aol-event="submitTfn"]', function ( event ) {
            FSSWEB.finSynAPI.analytics.setProcessComplete( 'ssc', 'provide-tfn', null );
        } );

        $( '.MyDetailsPlace' ).on( 'click', '.fn_setCancelReset', function ( event ) {
            FSSWEB.finSynAPI.analytics.setProcessStart( 'ssc', 'update-contact', null );
        } );

        $( '#aoli-confirmMyDetails' ).on( 'click', function ( event ) {
            event.preventDefault();
            $eb.trigger( "MyDetails.confirm" );
        } );
    };

});