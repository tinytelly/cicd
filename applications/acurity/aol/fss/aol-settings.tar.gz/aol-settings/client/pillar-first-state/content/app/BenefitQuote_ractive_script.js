/**
 * Created by charlesc on 19/11/2015.
 */
(function( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;
    //options.data.$place = {};
    //var namespace = FinSyn.places.benefitQuote;


    //setup oncomplete binding
    options.complete = function () {

    }
});
