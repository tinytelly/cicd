(function ( options ) {
    var window = $wnd;
    var Promise = window.Promise;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;

    options.incProjExp = {};

    options.incProjExp.constructDataModel = function() {
        options.incProjExp.dataModel = {
            data: JSON.parse( options.data.rc.incomeProjectionExportData )
        };
    };

    options.incProjExp.constructUI = function() {
        options.incProjExp.updateUI();
    };

    options.incProjExp.updateUI = function() {
        options.incProjExp.ractive.set( "dataModel", options.incProjExp.dataModel );
    };

    options.incProjExp.firePdfGenerateEvent = function() {
        // it fires event to notify phantomjs to start PDF generation
        // also see AolApp/phantomjs/generatePDF.js
        if ( typeof window.callPhantom === "function" ) {
            window.setTimeout(function () {
                window.callPhantom( {
                    type: "AolReadyForPdf event"
                } );
            }, 100 );
        }
    }

    options.complete = function () {
        options.incProjExp.ractive = this;
        options.incProjExp.constructDataModel();
        options.incProjExp.constructUI();
        options.incProjExp.firePdfGenerateEvent();
    };
});