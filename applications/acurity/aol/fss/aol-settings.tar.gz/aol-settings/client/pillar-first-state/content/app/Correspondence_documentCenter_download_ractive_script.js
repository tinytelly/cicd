(function ( options ) {
    var window = $wnd;
    var $ = window.$;
    var FinSyn = window.FinSyn;
    var FSSWEB = window.FSSWEB;
    //options.data.$place = {};

    //setup oncomplete binding
    options.complete = function () {
        var ractive = this;
        var $eb = ractive.$eb;

        $( '.correspondenceList_statements table.list-table__table' ).on( 'click', 'td > a', function ( e ) {
            FSSWEB.finSynAPI.pageSpinner.start();
            var statementLink = e.toElement || e.relatedTarget || e.currentTarget;
            var documentId = $(statementLink).attr( 'data-document-id' );
            var documentUrl = $(statementLink).attr( 'data-document-url' );

            var cleanup = function () {
                $eb.off( successHandler );
                $eb.off( failureHandler );
            }

            var successHandler = $eb.on( 'Correspondence.documentCenter.statement.download.done', function ( eventName, data ) {
                var downloadAnchor = $( '#download-statements-modal a.download' );
                FSSWEB.finSynAPI.pageSpinner.stop();
                FSSWEB.finSynAPI.modals.open(
                        'download-statements-modal',
                        function(){
                        }, {}, '{}',
                        {
                            'download': function () {
                                window.open( data.downloadUrl, '_blank' );
                                FSSWEB.finSynAPI.modals.close();
                            },
                            'back': function() {
                                //downloadAnchor.attr( 'href', 'javascript:;' );
                            }
                        }
                );
                cleanup();
            } );

            var failureHandler = $eb.on( 'Correspondence.documentCenter.statement.download.failed', function ( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                FSSWEB.finSynAPI.modals.open( 'unable-download-modal', function(){}, {}, '{}', null );
                cleanup();
            } );

            $eb.trigger( 'Correspondence.documentCenter.statement.download', {"documentId": documentId, "documentUrl": documentUrl} );
        } );

        $( '.correspondenceList_otherDocuments table.list-table__table' ).on( 'click', 'td > a', function ( e ) {

            FSSWEB.finSynAPI.pageSpinner.start();
            var statementLink = e.toElement || e.relatedTarget || e.currentTarget;
            var documentId = $(statementLink).attr( 'data-document-id' );
            var documentUrl = $(statementLink).attr( 'data-document-url' );

            var cleanup = function () {
                $eb.off( successHandler );
                $eb.off( failureHandler );
            }

            var successHandler = $eb.on( 'Correspondence.documentCenter.statement.download.done', function ( eventName, data ) {
                var downloadAnchor = $( '#download-others-modal a.download' );
                FSSWEB.finSynAPI.pageSpinner.stop();
                FSSWEB.finSynAPI.modals.open(
                        'download-others-modal',
                        function(){
                        }, {}, '{}',
                        {
                            'download': function () {
                                window.open( data.downloadUrl, '_blank' );
                                FSSWEB.finSynAPI.modals.close();
                            },
                            'back': function() {
                                //downloadAnchor.attr( 'href', 'javascript:;' );
                            }
                        }
                );
                cleanup();
            } );

            var failureHandler = $eb.on( 'Correspondence.documentCenter.statement.download.failed', function ( eventName, data ) {
                FSSWEB.finSynAPI.pageSpinner.stop();
                FSSWEB.finSynAPI.modals.open( 'unable-download-modal', function(){}, {}, '{}', null );
                cleanup();
            } );

            $eb.trigger( 'Correspondence.documentCenter.statement.download', {"documentId": documentId, "documentUrl": documentUrl} );
        } );
    }
});