(function ( options ) {
    var window = $wnd;
    var $ = $wnd.$;
    var FinSyn = $wnd.FinSyn;
    var FSSWEB = $wnd.FSSWEB;

    options.data.equalsIgnoreCase = function ( str1, str2 ) {
        return str1.getValue().trim().toUpperCase() == str2.getValue().trim().toUpperCase();
    };

    options.init = function () {
        //setup ractive level function
        var $ractive = this;
        $ractive.$fss_update = FSSWEB.update;
    }

    options.complete = function () {
        var $ractive = this;
        var $eb = $ractive.$eb;

        var initSelectedAccount = $( 'select.accountSelector.fn_dropdown-tiles option.preSelected' ).val();
        $( '#select-destination-account' ).on( 'panelWasSubmitted.finsyn-flowformNav', function ( e ) {
            var selectedAccount = $( 'select.accountSelector.fn_dropdown-tiles option:selected' ).val();
            if ( initSelectedAccount == selectedAccount ) {
                FSSWEB.finSynAPI.flowforms.nextPanel();
                return;
            }
            $eb.trigger( 'RolloverSuperStream.accountSelected', {"selectedAccount": selectedAccount} );
            e.stopPropagation();
            e.preventDefault();
        } );

        $( 'a.fancy.fn_consolidate__add-account-link' ).on( 'addAccountLinkClicked.finsyn-consolidateSuper', function ( e ) {
            var addHandler = $eb.on( 'RolloverSuperStream.fund.added', function ( eventName, data ) {
                FSSWEB.update( '.fn_consolidate-subform' );
                $eb.off( addHandler );
            } );
            $eb.trigger( 'RolloverSuperStream.fund.add' );
        } );

        $( '.fn_consolidate-subform.consolidate__subform' ).on( 'clearAccountLinkClicked.finsyn-consolidateSuper', '.fn_consolidate-clear', function ( e ) {
            var removeHandler = $eb.on( 'RolloverSuperStream.fund.removed', function ( eventName, data ) {
                FSSWEB.update( '.fn_consolidate-subform' );
                e.finsyn.accept();
                if ( data.action === 'reset' ) {
                    $( '#input-200_input-200-check-0' ).trigger( 'change' );
                }
                $eb.off( removeHandler );
            } );
            var data = {"index": $( e.currentTarget ).attr( 'data-aol-fund-index' )}
            $eb.trigger( 'RolloverSuperStream.fund.remove', data );
        } );

        $( '.fn_consolidate-subform.consolidate__subform' ).on( 'click.finsyn-consolidateSuper', '.fn_consolidate-cancel', function ( e ) {
            var index = $( e.currentTarget ).attr( 'data-aol-fund-index' );
            $( '#input-0001-'+index ).val( '' );

            //send the event make sure the error is cleaned
            var data = {"index": index};
            $eb.trigger( 'RolloverSuperStream.fund.validation.clear', data );
        });

        $( '.fn_consolidate-subform.consolidate__subform' ).on( 'attemptedToSaveAccount.finsyn-consolidateSuper', '.fn_consolidate-save-account', function ( e ) {
            var $subForm = $( e.target );

            FSSWEB.finSynAPI.flowforms.startSpinner();
            var cleanup = function () {
                $eb.off( successRemover );
                $eb.off( failureRemover );
            }
            var successRemover = $eb.on( 'RolloverSuperStream.fund.validation.passed', function ( eventName, data ) {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                FSSWEB.finSynAPI.consolidateSuper.saveIsValid( $subForm );

                var updateRemover = $eb.on( 'RolloverSuperStream.fund.selected.updated', function ( eventName, data ) {
                    //triggers the change to UI
                    $( '#input-200_input-200-check-' + data.index ).trigger( 'change' );
                    $eb.off( updateRemover );
                } );

                var index = $( e.currentTarget ).attr( 'data-aol-fund-index' );
                var selected = {"index": index};
                $eb.trigger( 'RolloverSuperStream.fund.selected', selected );
                cleanup();
            } );
            var failureRemover = $eb.on( 'RolloverSuperStream.fund.validation.failed', function ( eventName, data ) {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                FSSWEB.finSynAPI.consolidateSuper.saveIsNotValid( $subForm );
                cleanup();
            } );
            var data = {"index": $( e.currentTarget ).attr( 'data-aol-fund-index' )};
            $eb.trigger( 'RolloverSuperStream.fund.validation', data );
        } );

        $( '.flowform__wrap' ).on( 'panelWasSubmitted.finsyn-flowformNav', '#enter-accounts-to-combine', function ( e ) {
            FSSWEB.finSynAPI.flowforms.startSpinner();
            var cleanup = function () {
                $eb.off( successRemover );
                $eb.off( failureRemover );
                $eb.off( noSelectRemover );
            }
            var successRemover = $eb.on( 'RolloverSuperStream.fundList.validation.passed', function () {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                FSSWEB.finSynAPI.flowforms.nextPanel();
                cleanup();
            } );
            var failureRemover = $eb.on( 'RolloverSuperStream.fundList.validation.failed', function () {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                cleanup();
            } );
            var noSelectRemover = $eb.on( 'RolloverSuperStream.fundList.validation.noTransferSelected', function () {
                FSSWEB.finSynAPI.flowforms.stopSpinner();
                FSSWEB.finSynAPI.modals.open( 'modal-no-account-selected', function () {}, {}, '{}', {} );
                cleanup();
            } );
            $eb.trigger( 'RolloverSuperStream.fundList.validation', null );
        } );

        $( '#confirmation .formpanel__nextlink' ).on( 'click', function ( e ) {
            var validation = {
                "event": 'RolloverSuperStream.fundList.submit.validationFailed',
                "handler": function () {
                    //TODO: what do we do here?, it shouldn't happen, well normally.
                    //FSSWEB.pageSpinner.stopSpinner();
                }
            }
            var success = {
                "event": 'RolloverSuperStream.fundList.submit.submitted',
                "handler": function () {
                    //FSSWEB.pageSpinner.stopSpinner();
                }
            }
            var failure = {
                "event": 'RolloverSuperStream.fundList.submit.failed',
                "handler": function () {
                    //FSSWEB.pageSpinner.stopSpinner();
                }
            }

            //FSSWEB.pageSpinner.startSpinner();
            $eb.once( validation, success, failure );
            $eb.trigger( 'RolloverSuperStream.fundList.submit' );
        } );


        //init page status
        $eb.once( {
            "event": 'RolloverSuperStream.reloadPlace.sameAccount',
            "handler": function () {
                FSSWEB.finSynAPI.flowforms.nextPanel();
            }
        } )
        $eb.trigger( 'RolloverSuperStream.reloadPlace' );
    }
});